import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class JsonToDrlConverter {

    public static void main(String[] args) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            JsonNode rootNode = mapper.readTree(new File("src/main/resources/input.json"));
            JsonNode conditionalJson = rootNode.get("conditionalJson");

            String drlContent = convertToDrl(conditionalJson);

            // Write to DRL file
            FileWriter writer = new FileWriter(new File("target/output.drl"));
            writer.write(drlContent);
            writer.close();

            System.out.println("DRL file generated successfully.");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static String convertToDrl(JsonNode node) {
        StringBuilder drl = new StringBuilder();

        // Assuming this is the start of the rule definition
        drl.append("rule \"Generated Rule\"\n");
        drl.append("    when\n");

        processRules(node.get("rules"), node.get("combinator").asText(), drl, 2);

        drl.append("    then\n");
        drl.append("        // Add actions here\n");
        drl.append("end\n");

        return drl.toString();
    }

    private static void processRules(JsonNode rules, String combinator, StringBuilder drl, int indentLevel) {
        String indent = "    ".repeat(indentLevel);

        drl.append(indent).append("(");

        for (int i = 0; i < rules.size(); i++) {
            JsonNode rule = rules.get(i);

            if (rule.has("rules")) {
                // Nested rule
                processRules(rule.get("rules"), rule.get("combinator").asText(), drl, indentLevel + 1);
            } else {
                // Simple condition
                String field = rule.get("field").asText();
                String operator = mapOperator(rule.get("operator").asText());
                String value = rule.get("value").get("value").asText();

                drl.append(field).append(" ").append(operator).append(" \"").append(value).append("\"");
            }

            if (i < rules.size() - 1) {
                drl.append(" ").append(combinator).append(" ");
            }
        }

        drl.append(")\n");
    }

    private static String mapOperator(String operator) {
        switch (operator) {
            case "=":
                return "==";
            // Add more operators if needed
            default:
                return operator;
        }
    }
}
